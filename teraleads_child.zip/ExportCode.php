<?php
require_once("vtlib/Vtiger/Module.php");

$adb = PearDatabase::getInstance();

$mysqlDatabaseName ='p5408_7';
$mysqlUserName ='p5408_7';
$mysqlPassword ='DqQSe8yZAChw';
$mysqlHostName ='cl1-sql16';
//$time=getdate();
$mysqlExportPath ='waodigital.sql';
//$mysqldump=exec('which mysqldump');
$command="tar cvzf teraleads.tar.gz --exclude='storage' --exclude='*.sql' --exclude='*.zip' --exclude='backup' --exclude='*.tgz' --exclude='*.gz' --exclude='*.tar' --exclude='*.bzip2' --exclude='*_bak' --exclude='*_final' *";
exec($command,$output=array(),$worked);
switch($worked){
    case 0:
        echo 'Done';
        break;
    case 1:
        echo 'There was a warning';
        break;
    case 2:
        echo 'There was an error during export. Please check your information again';
        break;
}

