<link href="style.css" rel="stylesheet">
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
<script src="jquery.validate.min.js" type="text/javascript"></script>
<div class="container">
    <div class="text">
        Setup your child crm
    </div>
    <form method="post" id="frmSetup">
        <div class="form-row">
            <div class="input-data">
                <input type="text" name="username" value="<?php isset($_POST['username'])? $_POST['username']:""?>" placeholder="Mysql username" required>
                <div class="underline"></div>
            </div>
            <div class="input-data">
                <input type="password" name="password" placeholder="Mysql Password" required>
                <div class="underline"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="input-data textarea">
                <input type="text" name="dbhost" value="<?php isset($_POST['dbhost'])? $_POST['dbhost']:"" ?>" placeholder="Database server" required>
                <div class="underline"></div>
            </div>
            <div class="input-data textarea">
                <input type="text" name="dbname" value="<?php isset($_POST['dbname'])? $_POST['dbname']:"" ?>" placeholder="Database name" required>
                <div class="underline"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="input-data textarea">
                <input type="text" name="siteUrl" value="<?php isset($_POST['siteUrl']) ? $_POST['siteUrl'] :  pathUrl() ?>" placeholder="Vtiger Url" required>
                <div class="underline"></div>
            </div>
        </div>
        <div class="form-row">
            <div class="input-data">
                <div class="form-row submit-btn">
                    <div class="input-data">
                        <div class="inner"></div>
                        <input type="submit" name="submit" value="submit" onclick="ShowProgressAnimation();">
                    </div>
                </div>
            </div>
		</div>
    </form>
</div>
<div id="loading-div-background">
  <div id="loading-div" class="ui-corner-all">
    <img style="height:32px;width:32px;margin:30px;" src="please_wait.gif" alt="Loading.."/><br>PROCESSING. PLEASE WAIT...
  </div>
</div>
<script type="text/javascript">
    $(document).ready(function (){
        $("#loading-div-background").css({ opacity: 1.0 });
    });
	

    function ShowProgressAnimation(){
		//$("#frmSetup").submit();
		$("#frmSetup").validate({
			rules: {
			  username: "required",
			  password: "required",
			  dbhost: "required",
			  siteUrl: "required",
			  dbname: "required"		  
			},

			messages: {
			  username: "Please enter DB username",
			  lastname: "Please enter DB Password",		  
			  dbhost: "Please enter dbhost",		  
			  siteUrl: "Please enter siteUrl",		  
			  dbname: "Please enter dbname",		  
			},
			submitHandler: function(form) {
			  $("#loading-div-background").show();	
			  form.submit();
			}
		});        
    }
</script>
<?php
//ini_set('display_errors',1);
if(isset($_POST['submit'])){
    $userName = $_POST['username'];
    $password = $_POST['password'];
    $dbName = $_POST['dbname'];
    $siteUrl = isset($_POST['siteUrl']) ? $_POST['siteUrl']: pathUrl();
    $dbhost =  isset($_POST['dbhost']) ? $_POST['dbhost'] : "localhost";
    //Import data first
    $run=   exec ("mysql -h$dbhost -u$userName -p$password $dbName < teraleads_child.sql ", $out);
    //Update vtiger config file
    $filename = "config.inc.php";
    $str = file_get_contents($filename);
    $str = str_replace('_DB_USER_NAME_', $userName,$str);
    $str = str_replace('_DB_PASSWORD_', $password,$str);
    $str = str_replace('_DB_SERVER_HOST_', $dbhost,$str);
    $str = str_replace('_DB_NAME_', $dbName,$str);
    $str = str_replace('_SITE_URL_', $siteUrl,$str);
    file_put_contents($filename, $str);
    $vtiger_link = pathUrl();
	unlink('setup.php');
	unlink('extract.php');
	unlink('jquery.validate.min.js');
	unlink('style.css');
	unlink('please_wait.gif');
    header('Location:'.$siteUrl);
	echo "<script>window.location.href='$siteUrl';</script>";
    exit;
}
function pathUrl($dir = __DIR__){
    $root = "";
    $dir = str_replace('\\', '/', realpath($dir));

    //HTTPS or HTTP
    $root .= !empty($_SERVER['HTTPS']) ? 'https' : 'http';
    //HOST
    $root .= '://' . $_SERVER['HTTP_HOST'].'/';
    //ALIAS
    if(!empty($_SERVER['CONTEXT_PREFIX'])) {
        $root .= $_SERVER['CONTEXT_PREFIX'];
        $root .= substr($dir, strlen($_SERVER[ 'CONTEXT_DOCUMENT_ROOT' ]));
    } else {
        $root .= substr($dir, strlen($_SERVER[ 'DOCUMENT_ROOT' ]));
    }
    $root .= '/';
    return $root;
}